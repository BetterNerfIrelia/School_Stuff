package at.fhv.ssc.fastfood;

/**
 * Created by sebastian on 05.09.2017.
 */
public class Main {

    public static void main(String [] args){

        FastFood food = new FastFood();


    }

}
