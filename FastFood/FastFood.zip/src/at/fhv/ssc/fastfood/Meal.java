package at.fhv.ssc.fastfood;

/**
 * Created by sebastian on 05.09.2017.
 */
public class Meal {

    private int _name;
    private int _number;

    public Meal(){


    }

}
