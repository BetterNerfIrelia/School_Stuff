package at.fhv.tree;

public interface Tree {

    public void createTree(StringBuilder str, boolean searchtree);

}