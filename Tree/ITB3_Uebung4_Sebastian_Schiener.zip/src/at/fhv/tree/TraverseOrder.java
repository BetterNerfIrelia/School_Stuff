package at.fhv.tree;

public interface TraverseOrder {

    public void traverse(Node node);

}
