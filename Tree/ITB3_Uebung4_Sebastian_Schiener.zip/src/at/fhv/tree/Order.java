package at.fhv.tree;

public enum Order {

    PREORDER, INORDER, POSTORDER, LEVELBYLEVEL

}


