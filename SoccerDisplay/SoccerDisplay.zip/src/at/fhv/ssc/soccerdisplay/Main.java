package at.fhv.ssc.soccerdisplay;

/**
 * Created by sebastian on 05.09.2017.
 */
public class Main {

    public static void main(String [] args){

        SoccerDisplay ball = new SoccerDisplay();
        ball.setScore("00:00");

    }
}
