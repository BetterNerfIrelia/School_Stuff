package at.fhv.scc.tictactoe;

public interface Opponent {


    public void play();
    public void setGame(Game game);



    }
