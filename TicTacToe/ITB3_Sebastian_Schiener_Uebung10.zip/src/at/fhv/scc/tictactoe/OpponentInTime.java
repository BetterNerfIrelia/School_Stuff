package at.fhv.scc.tictactoe;

public class OpponentInTime implements Opponent {


    public void play(){



    }

    @Override
    public void setGame(Game game) {

    }


}
