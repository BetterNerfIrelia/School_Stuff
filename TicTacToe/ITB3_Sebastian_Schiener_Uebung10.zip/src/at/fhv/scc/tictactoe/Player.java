package at.fhv.scc.tictactoe;

import java.util.Scanner;

public class Player {

    public Player() {



    }
}
