package at.fhv.ssc.gameoflife2;

abstract class Being {

   abstract boolean isAlive();

}
