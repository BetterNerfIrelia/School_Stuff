package at.fhv.ssc.webserver;

public class Main {

    public static void main(String[] args) {

        WebServer server = new WebServer(8080);


    }

}
