package at.fhv.ssc;

public class Prim {
}
