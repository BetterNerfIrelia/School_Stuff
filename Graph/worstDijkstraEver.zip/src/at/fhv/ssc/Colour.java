package at.fhv.ssc;

public enum Colour {

    YELLOW, BLUE
}
