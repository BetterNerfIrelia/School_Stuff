package at.fhv.ssc;

public enum Operator {

    PLUS, MINUS, MULTIPLY, DIVIDE
}
