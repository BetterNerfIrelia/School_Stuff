package at.fhv.ssc;

public abstract class AdjacencyStructure {

    public abstract void print();

}
