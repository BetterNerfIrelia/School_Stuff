package at.fhv.ssc.stopwatch;

/**
 * Created by sebastian on 02.09.2017.
 */
public class Main {

    public static void main(String [] args){

StopWatch watch = new StopWatch();

    }


}
